// Stampa a video il valore dell'indice del BAR in real time

using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Linq;
using System;
using System.IO;
using System.Text;

public class Index : MonoBehaviour
{
    // Use this for initialization
    TcpListener listener;
    String msg;
    //public Text textComponent;
    Text txt;

    void Start()
    {
        listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 55002);
        listener.Start();
        print("is listening");
        txt = gameObject.GetComponent<UnityEngine.UI.Text>();
    }
    // Update is called once per frame
    void Update()
    {
        if (!listener.Pending())
        {
        }
        else
        {
            print("socket comes");
            TcpClient client = listener.AcceptTcpClient();
            NetworkStream ns = client.GetStream();
            StreamReader reader = new StreamReader(ns);
            msg = reader.ReadToEnd();
            txt.text = "BAR: " + msg;
        }
    }
}
