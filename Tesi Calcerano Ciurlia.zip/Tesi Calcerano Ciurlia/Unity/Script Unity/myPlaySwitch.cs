// Cambia una sorgente audio in funzione del valore di BAR, quando tale valore scende sotto una determinata soglia viene accesa una sorgente audio con il volume che cambia
// in funzione del parametro stesso. Pi� ci si avvicina alla soglia minore � il volume dell'audio, quando si supera questa soglia, viene fatto lo switch della sorgente audio.

// Ad esempio, supponendo di avere un indice che oscilla da 0 a 2, e di porre la soglia ad 1. Quando l'indice � a 0 la sorgente 1 � al volume massimo, se sale, il volume diminuisce
// fino ad arrivare a 0 nel momento in cui l'indice arriva a 1, a questo punto inizia a salire il volume della sorgente audio 2, che arriva al massimo quando l'idice arriva a 2.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net;
using System.Net.Sockets;
using System.Linq;
using System;
using System.IO;
using System.Text;


public class myPlaySwitch : MonoBehaviour
{
    TcpListener listener;
    String msg;
    private float position;
    private float value;
    public AudioSource _AudioSource1;
    public AudioSource _AudioSource2;

    void Start()
    {

        _AudioSource1.Play();
        //_AudioSource2.Stop();
        listener = new TcpListener(IPAddress.Parse("10.80.1.14"), 55002);
        listener.Start();
        print("is listening");

    }


    void Update()
    {

            if (!listener.Pending())
            {
            }
            else
            {
                // print the message that unity is listening.
                print("socket comes");
                TcpClient client = listener.AcceptTcpClient();
                NetworkStream ns = client.GetStream();
                StreamReader reader = new StreamReader(ns);
                msg = reader.ReadToEnd();
                print(msg);
                string msg1 = msg.Replace(".", ",");
                position = float.Parse(msg1);
                value = position / 5;

                    if (position < 5)
                    {

                        _AudioSource1.volume = 1 - (position / 5);
                        _AudioSource2.Stop();

                    }
                    else
                    {

                        _AudioSource1.Stop();
                        _AudioSource2.Play();
                        _AudioSource2.volume = 1 - (position / 5);

                    }

            }


    }

}
