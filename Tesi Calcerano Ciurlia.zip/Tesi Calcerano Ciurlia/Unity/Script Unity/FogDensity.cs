// Gestisce la variazione della nebbia in funzione del BAR inviato in Real time da MATLAB

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net;
using System.Net.Sockets;
using System.Linq;
using System;
using System.IO;
using System.Text;


public class FogDensity : MonoBehaviour
{

    // Use this for initialization
    // TcpListener � una funzione presente nella libreria System.Net.Sockets
    // TcpClient, TcpListener e Socket sono metodi che permettono di creare una connessione nella rete, necessitano di un indirizzo IP e di una porta sulla quale leggere 
    // e scambiare i dati. In generale, il metodo Socket � pi� a basso livello e permette quindi di gestire in maniera pi� precisa tutto il processo 
    // mentre TcpClient e TcpListener sono pi� ad alto livello, nel nostro caso, MATLAB viene impostato come TcpClient ed ha la possibilit� di leggere, caricare e modificare
    // i dati che sono presenti nel server che si crea appena viene fatta la connessione, Unity viene invece impostato come TcpListener ed ha solo la possibilit� di leggere i 
    // dati che sono presenti sul server. 


    TcpListener listener;
    // the msg is the value that you put in the msg matrix in matlab
    String msg;
    public float position;

    void Start()
    {
        // Attiva la nebbia nello scenaio
        RenderSettings.fog = true;
        // Creazione della connessione TCP/IP e inizializzazione
        // Nel momento dell'inizializzazione � necessario specificare indirizzo IP e la porta. 
        // La porta pu� essere un numero a caso tra 1 e 65000, ogni parametro da modificare nello scenario necessita di una nuova connessione 
        // e quindi di una nuova porta.
        // L'indirizzo IP deve essere 127.0.0.1 nel caso in cui si voglia fare una connessione con il pc stesso
        // Nel caso in cui si voglia fare una connessione con un devide esterno bisogna che sia il pc che il device siano connessi allo stesso wi-fi ed � necesaria
        // la modifica dell'indirizzo IP
        listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 55001);
        listener.Start();
        print("is listening");
    }

    // Update is called once per frame
    void Update()
    {
        if (!listener.Pending())
        {
        }
        else
        {
            // Controlla se ci sono connessioni in attesa:
            // la funzione Pending da 'True' se ci sono connessioni in attesa oppure 'False' se non c'� nessuna connessione
            // L'operatore ! davanti alla condizione controlla la condizione negativa (False), quindi se non c'� connessione entra nell'if e non fa nulla fino a quando 
            // non arriva la connessione, entra nell'else e svolge i comandi all'interno

            // print the message that unity is listening.
            print("socket comes");
            // Crea il client e accetta la richiesta di connessione tra client (MATLAB) e Listener (software sul quale gira questo script, cio� Unity)
            TcpClient client = listener.AcceptTcpClient();
            // Prende i dati che vengono inviati dal client
            NetworkStream ns = client.GetStream();
            // Prende e trasforma in istanza (classe di oggetto) il contenuto dei dati che sono stati mandati dal client
            StreamReader reader = new StreamReader(ns);
            // Legge i caratteri presenti all'interno di 'reader' dall'inizio alla fine (usando solo Read leggerebbe solo il carattere successivo e avanzerebbe di una posizione)
            msg = reader.ReadToEnd();
            
            //string msg1 = msg.Replace(".", ",");
            position = float.Parse(msg);
            float density = position / 1000000;
            print(position);
            RenderSettings.fogDensity = position / 100;

        }


        // this command allows to concatenate different if statement\

    }
}