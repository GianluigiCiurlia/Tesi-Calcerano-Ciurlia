using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net;
using System.Net.Sockets;
using System.Linq;
using System;
using System.IO;
using System.Text;
using UnityEngine.UI;


public class Bar : MonoBehaviour
{
    TcpListener listener;
    // the msg is the value that you put in the msg matrix in matlab
    String msg;
    public float position;
    public Slider BarL;
    private const float full = 10f;


    void Start()
    {
        BarL = GetComponent<Slider>();
        //RenderSettings.fog = true;
        listener = new TcpListener(IPAddress.Parse("10.80.1.14"), 55002);
        listener.Start();
        print("is listening");
    }

    // Update is called once per frame
    void Update()
    {
        if (!listener.Pending())
        {
        }
        else
        {
            // print the message that unity is listening.
            print("socket comes");
            TcpClient client = listener.AcceptTcpClient();
            NetworkStream ns = client.GetStream();
            StreamReader reader = new StreamReader(ns);
            msg = reader.ReadToEnd();
            print(msg);
            string msg1 = msg.Replace(".", ",");
            position = float.Parse(msg1);
            //BarL = GetComponent<Image>();
            BarL.value = position / full;
            //RenderSettings.fogDensity = position / 1000;

        }


        // this command allows to concatenate different if statement\

    }
}

