// Modifica dello script Vibration.cs. 


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlarmLight : MonoBehaviour
{
	public float baseStart = 0.0f; // start 
	public float amplitude = 1.0f; // amplitude of the wave
	public float phase = 0.0f; // start point inside on wave cycle
	public float frequency = 1.0f; // cycle frequency per second

	// Keep a copy of the original color
	private Color originalColor;
	private Light luce;

	// Store the original color
	void Start()
	{
		luce = GetComponent<Light>();
		originalColor = luce.color;
	}

    // Update is called once per frame
    void Update()
    {

        // Time.time conta il tempo da quando inizia l'applicazione
        // Lo stress test dura 3 minuti, quindi 180 secondi, per mettere la luce negli ultimi 30 secondi, basta controllare che siano passati meno di 150 secondi
        // In questo caso l'intensit� della luce viene messa a 0, quando supera i 150 secondi viene fatta flickerare a 1 Hz con onda quadra. 

        if (Time.time < 150.0f)
        {
            luce.color = originalColor * 0.0f;
        }
        if (Time.time > 150.0f)
        {
            //luce.enabled = true;
            luce.color = originalColor * (EvalWave());
        }
    }

    float EvalWave()
    {
        float x = (Time.time + phase) * frequency;
        float y;
        x = x - Mathf.Floor(x); // normalized value (0..1)

        if (x < 0.5f)
        {
            y = 1.0f;
        }
        else
        {
            y = -1.0f;
        }
    

        return (y * amplitude) + baseStart;
    }
}
