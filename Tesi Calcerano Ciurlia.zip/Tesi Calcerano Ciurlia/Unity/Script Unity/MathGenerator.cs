// Codice per la gestione dello stress test.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class MathGenerator : MonoBehaviour
{

    public int var1;
    public int var2;
    public int res;
    public int var3;
    public int cont;
    public bool control;

    public Text ValueText;
    public Text Result;
    public Text Count;
    public bool TimerOn = false;
    public bool TimerOn_2 = false;
    public float TimeLeft = 10.0f;              // Primo timer da 10 secondi per la singola operazione
    public float TimeLeft_2 = 180.0f;           // Secondo timer da 180 secondi (3 minuti) per l'intero test
    public Text TimerTxt;

    public ParticleSystem explosion;
    public AudioSource expl_sound;

    // Start is called before the first frame update
    void Start()
    {

        ParticleSystem explosion = GetComponent<ParticleSystem>();
        Text Count = GetComponent<Text>();
        TimerOn = true;                         // Fa partire il primo timer dei 10 secondi
        TimerOn_2 = true;                       // Fa partire il timer dei 3 minuti
        Math();                                 // Richiama la routine Math() che serve per generare una nuova operazione
    }

    void Update()
    {

        print(Time.deltaTime);
        if (TimerOn)
        {
            // TimeLeft � una variabile che conta il tempo mancante alla fine del tempo, ogni frame viene aggiornata e le viene sottratto il tempo passato
            // tra il frame corrente e il frame precedente (Time.deltaTime)
            if (TimeLeft > 0)
            {
                TimeLeft -= Time.deltaTime;
                updateTimer(TimeLeft);
            }
            // Nel momento in cui scade il timer, viene reinizializzato, generata una nuova operazione, e fatta partire l'esplosione
            else
            {
                TimeLeft = 10.0f;
                Math();
                explosion.Play();
                expl_sound.Play();
            }
        }

        if (TimerOn_2)
        {
            if (TimeLeft_2 > 0)
            {
                TimeLeft_2 -= Time.deltaTime;
                updateTimer_2(TimeLeft_2);
            }
            else
            {
                TimeLeft_2 = 0;
                TimerOn_2 = false;
                
            }
        }

    }

    // Update is called once per frame
    public void Math()
    {

        // Genera un numero casuale tra 1 e 4, ad ogni numero corrisponde una diversa operazione

        int var4 = UnityEngine.Random.Range(1, 5);
        if (var4 == 1)
        {

            // Genera due numeri causali tra 20 e 99

            var1 = UnityEngine.Random.Range(20, 100);
            var2 = UnityEngine.Random.Range(20, 100);

            res = var1 + var2;

            // Genera una variabile binaria tra 0 e 1 in maniera randomica
            // L'operazione mostrata a video sar� 'VAR1 + VAR2 = VAR3'
            // Se viene generato 'true' allora verr� generata un'operazione con risultato corretto, viene quindi posto var3 = var1 + var2
            // Se viene generato 'false' allora verr� generata un'operazione con risultato errato, viene quindi posto var3 = un numero casuale compreso in un range scelto

            System.Random rnd = new System.Random();
            control = rnd.Next(2) == 1;
 
            if (control == true)
            {
                var3 = res;
            }
            else
            {
                var3 = UnityEngine.Random.Range(res - 20, res + 20);
            }


            // Stampa nella casella di testo dell'operazione.

            ValueText.text = string.Concat(var1 + " plus " + var2 + " equal to " + var3);
        }

        if (var4 == 2)
        {
            var1 = UnityEngine.Random.Range(20, 100);
            var2 = UnityEngine.Random.Range(20, 100);

            res = var1 - var2;

            System.Random rnd = new System.Random();
            control = rnd.Next(2) == 1;
            //int control = Random.Range(0, 100);

            if (control == true)
            {
                var3 = res;
            }
            else
            {
                var3 = UnityEngine.Random.Range(res - 20, res + 20);
            }

            ValueText.text = string.Concat(var1 + " minus " + var2 + " equal to " + var3);
        }

        if (var4 == 3)
        {
            var1 = UnityEngine.Random.Range(20, 100);
            var2 = UnityEngine.Random.Range(20, 100);

            res = var1 * var2;

            System.Random rnd = new System.Random();
            control = rnd.Next(2) == 1;
            //int control = Random.Range(0, 100);

            if (control == true)
            {
                var3 = res;
            }
            else
            {
                var3 = UnityEngine.Random.Range(res - 20, res + 20);
            }

            ValueText.text = string.Concat(var1 + " multiply by " + var2 + " equal to " + var3);
        }

        if (var4 == 4)
        {
            var1 = UnityEngine.Random.Range(20, 100);
            var2 = UnityEngine.Random.Range(20, 100);

            res = var1 / var2;

            System.Random rnd = new System.Random();
            control = rnd.Next(2) == 1;
            //int control = Random.Range(0, 100);

            if (control == true)
            {
                var3 = res;
            }
            else
            {
                var3 = UnityEngine.Random.Range(res - 20, res + 20);
            }

            //var3 = UnityEngine.Random.Range(res - 1, res + 1);
            ValueText.text = string.Concat(var1 + " divided by " + var2 + " equal to " + var3);
        }

    }


    // Le routine Correct e Wrong si attivano quando si clicca nel gioco sul rispettivo tasto.

    public void Correct()
    {

        if (var3 == res)
        {
            // Cliccando su Correct, se il risulato mostrato a video (var3) � uguale al risultato teorico (res), viene mostrato la scritta 'Correct!'
            Result.text = "Correct!";
        }
        else
        {
            // Cliccando su Correct, se il risulato mostrato a video (var3) � diverso dal risultato teorico (res), viene mostrato la scritta 'Error!' e parte l'esplosione
            Result.text = "Error!";
            explosion.Play();
            expl_sound.Play();
        }

        // A prescindere dall'esito dell'operazione, dopo aver cliccato il tasto si genera un nuovo timer (Reinizializzato TimeLeft e richiamata la funzione Update che 
        // gestisce il timer) e una nuova operazione
        TimeLeft = 10.0f;
        Math();
        Update();
    }


    public void Wrong()
    {

        if (var3 == res)
        {
            // Cliccando su Error, se il risulato mostrato a video (var3) � uguale al risultato teorico (res), viene mostrato la scritta 'Error!' e parte l'esplosione
            Result.text = "Error!";
            explosion.Play();
            expl_sound.Play();
        }
        else
        {
            // Cliccando su Error, se il risulato mostrato a video (var3) � diverso dal risultato teorico (res), viene mostrato la scritta 'Correct!'
            Result.text = "Correct!";
        }


        // A prescindere dall'esito dell'operazione, dopo aver cliccato il tasto si genera un nuovo timer (Reinizializzato TimeLeft e richiamata la funzione Update che 
        // gestisce il timer) e una nuova operazione

        TimeLeft = 10.0f;
        Math();
        Update();

    }


    // Routine che gestiscono il timer, trovate su internet.

    void updateTimer(float currentTime)
    {
        currentTime += 1;

        float minutes = Mathf.FloorToInt(currentTime / 60);
        float seconds = Mathf.FloorToInt(currentTime % 60);

        Count.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    void updateTimer_2(float currentTime)
    {
        currentTime += 1;

        float minutes = Mathf.FloorToInt(currentTime / 60);
        float seconds = Mathf.FloorToInt(currentTime % 60);

        TimerTxt.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }


}








