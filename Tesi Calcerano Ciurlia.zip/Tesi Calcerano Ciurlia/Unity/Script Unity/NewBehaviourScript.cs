// Script per implementare il ciclo notte giorno, non pi� usato, va legato ad una Luce Direzionale


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net;
using System.Net.Sockets;
using System.Linq;
using System;
using System.IO;
using System.Text;
using UnityEngine.UI;


public class NewBehaviourScript : MonoBehaviour
{
    TcpListener listener;
    // the msg is the value that you put in the msg matrix in matlab
    String msg;
    public float position;
    public Light directionalLight;
    Camera targetCam;


    void Start()
    {
        //lightIntensity = directionalLight.intensity;
        //RenderSettings.fog = true;
        listener = new TcpListener(IPAddress.Parse("10.80.1.14"), 55003);
        listener.Start();
        print("is listening");
    }

    // Update is called once per frame
    void Update()
    {

        if (!listener.Pending())
        {
        }
        else
        {
            // print the message that unity is listening.
            print("socket comes");
            TcpClient client = listener.AcceptTcpClient();
            NetworkStream ns = client.GetStream();
            StreamReader reader = new StreamReader(ns);
            msg = reader.ReadToEnd();
            print(msg);
            string msg1 = msg.Replace(".", ",");
            position = float.Parse(msg1);

            if (position > 0)
                transform.Rotate(10f * Time.deltaTime, 0f * Time.deltaTime, 0f * Time.deltaTime, Space.Self);

        }


        // this command allows to concatenate different if statement\

    }
}
