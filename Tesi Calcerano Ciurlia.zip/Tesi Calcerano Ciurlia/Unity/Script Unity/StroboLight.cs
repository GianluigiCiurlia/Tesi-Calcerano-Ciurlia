// Script che gestisce la prova di luce Stroboscopica

// Nella simulazione ci sono 35 combinazioni totali di frequenza/intensit�, ogni combinazione presenta 30 secondi di stimolazione e 2 secondi di pausa.
// StartCoroutine vinene quindi richiamata ogni 32 secondi, incremenanto di 1 un contatore che cicla sui vettori di combinazioni (ogni 32 secondi si passa alla combinazione successiva)

// Indice  = (Time.time - ((multiplier-1f)*32f))
// Time.time conta il tempo dall'inizio della prova, nel caso in cui ci si trovasse alla prima combinazione, Time.time parte da 0, multiplier = 1, quindi Indice sar�
// semplicemente aggiornato come time counter dall'inizio della prova.

// Una volta superati i primi 32 secondi, Time.time continua a crescere superando il valore 32, e multiplier si aggiorna di 1.
// La strategia utilizzata � stata quindi quella di togliere il valore (multiplier-1)*32 in modo da far far ricominciare "Indice" da 0 ad ogni iterazione.



using UnityEngine;
using System.Collections;



public class StroboLight : MonoBehaviour
{

	public enum WaveForm { sin, tri, sqr, saw, inv, noise };
	public WaveForm waveform = WaveForm.sin;

	public float baseStart = 0.0f; // start 
	public float amplitude = 1.0f; // amplitude of the wave
	public float phase = 0.0f; // start point inside on wave cycle
	public float frequency = 0.5f; // cycle frequency per second
	public float IAF = 0.5f; // cycle frequency per second
	int multiplier = 0;
	
	// Keep a copy of the original color
	private Color originalColor;
	private Light light;
	
	// Store the original color
	void Start()
	{
		light = GetComponent<Light>();
		originalColor = light.color;
		StartCoroutine("StartFireSequence_Enumerator");
	}

	void Update()
	{
		float[] vector1 = { IAF + 3f, IAF -3f, IAF-2f, IAF-1f, IAF, IAF+1f, IAF+2f, IAF+3f, IAF - 3f, IAF - 2f, IAF - 1f, IAF, IAF + 1f, IAF + 2f, IAF + 3f , IAF - 3f, IAF - 2f, IAF - 1f, IAF, IAF + 1f, IAF + 2f, IAF + 3f , IAF - 3f, IAF - 2f, IAF - 1f, IAF, IAF + 1f, IAF + 2f, IAF + 3f , IAF - 3f, IAF - 2f, IAF - 1f, IAF, IAF + 1f, IAF + 2f, IAF + 3f };
		float[] vector2 = {0f, 1.42f, 1.42f, 1.42f, 1.42f, 1.42f, 1.42f, 1.42f, 8.34f, 8.34f, 8.34f, 8.34f, 8.34f, 8.34f, 8.34f, 52.8f, 52.8f, 52.8f, 52.8f, 52.8f, 52.8f, 52.8f, 326f, 326f, 326f, 326f, 326f, 326f, 326f, 326f, 7158f, 7158f, 7158f, 7158f, 7158f, 7158f, 7158f };
		//print(vector1[34]);


		frequency = vector1[multiplier - 1];
		amplitude = vector2[multiplier - 1];

		light.color = originalColor * (EvalWave());


		if (((Time.time - ((multiplier-1f)*32f)) > 30.0f) && ((Time.time - ((multiplier-1f) * 32f)) <= 32.0f))
		{
			light.color = originalColor*0f;
		}

	}


	float EvalWave()
	{
		float x = (Time.time + phase) * frequency;
		float y;
		x = x - Mathf.Floor(x); // normalized value (0..1)

		if (waveform == WaveForm.sin)
		{

			y = Mathf.Sin(x * 2 * Mathf.PI);
		}
		else if (waveform == WaveForm.tri)
		{

			if (x < 0.5f)
				y = 4.0f * x - 1.0f;
			else
				y = -4.0f * x + 3.0f;
		}
		else if (waveform == WaveForm.sqr)
		{

			if (x < 0.5f)
				y = 1.0f;
			else
				y = -1.0f;
		}
		else if (waveform == WaveForm.saw)
		{

			y = x;
		}
		else if (waveform == WaveForm.inv)
		{

			y = 1.0f - x;
		}
		else if (waveform == WaveForm.noise)
		{

			y = 1f - (Random.value * 2);
		}
		else
		{
			y = 1.0f;
		}
		return (y * amplitude) + baseStart;
	}

	IEnumerator StartFireSequence_Enumerator()
	{
		//yield return new WaitForSeconds(2.0f);
		while (true)
		{
			//amplitude = amplitude +  5.0f * Time.timeScale;
			
			multiplier = multiplier + 1;

			yield return multiplier;
			yield return new WaitForSeconds(32.0f * Time.timeScale);
		}
	}


	
}




