%Script di processing dei segnali off-line. Vengono processati sia i
%segnali EEG che i segnali ECG


clear all
close all
clc

%Caricamento del segnale dell'intera sessione di training (26 minuti: 780000 campioni)
data = load('Training_Dile_15_febbraio.easy');        

%Il segnale sarà una matrice di 78000 campioni x 13 colonne così organizzati: 
%Sulle prime 4 colonne ci saranno i segnali relativi ai canali scelti,
%O1,O2,F3,F4, ECG rispettivamente (ch1: O1, ch2: O2, ch3: F3, ch4: F4, ch5: ECG, selezionati 
%in questo modo sul protocollo del NIC). Tutti i segnali sono riferiti al CMS.
% Nei canali dal ch6 al ch8 (canali non utilizzati) sarà riportato il valore di fondoscala.
% Nei canali dal ch9 al ch11 vengono riportati i valori dell'accelerometro triassiale.
% Nel ch12 vengono i riportati eventuali marker inseriti durante l'acquisizione.
% Nel ch13 viene riportata una misura temporale relativa all'acquisizione.



%% IDENTIFICHIAMO I MARKER CHE CI DANNO INIZIO E FINE DI OGNI FASE

%Durante l'acquisizione abbiamo utilizzato il marker 1 per segnare l'inizio
%e la fine della Baseline 1 e della Baseline 2, il marker 2 per segnare
%l'inizio e la fine dello Stress Test, il marker 3 per segnare l'inizio e
%la fine della fase di Relax
marker1=find(data(:,12)==1);      %inizio e fine della baseline iniziale e della baseline finale
marker2=find(data(:,12)==2);      %inizio e fine dello stress test
marker3=find(data(:,12)==3);      %inizio e fine della fase di relax

%Definizione dell'inizio e fine di ogni fase; fare un check della corrispondenza in campioni. 
start_baseline1= marker1(1);      %-->dovrebbe essere intorno ai primi campioni
end_baseline1= marker1(2);        %-->dovrebbe essere intorno al campione 90000
start_stresstest= marker2(1);     %-->dovrebbe essere dopo il campione 90000
end_stresstest= marker2(2);       %-->dovrebbe essere intorno al campione 180000
start_relax= marker3(1);          %-->dovrebbe essere un bel po' dopo il campione 180000
end_relax= marker3(2);            %-->dovrebbe essere intorno al campione 630000
start_baseline2= marker1(3);      %-->dovrebbe essere dopo il campione 630000
end_baseline2= marker1(4);        %-->dovrebbe essere intorno al campione 720000   



%% SEGNALE EEG: filtraggio, calcolo della FFT, calcolo delle potenze di banda, calcolo del BAR e della asimmetria

%Per prima cosa facciamo il filtraggio dei canali EEG e ne calcoliamo la
%potenza spettrale in banda alpha e in banda beta, canale per canale. 
%Per valutare l'andamento temporale dei vari parametri di interesse, il
%calcolo viene effettuato ogni 2 secondi. Sono state fatte delle prove di
%calcolo utilizzando brani di segnale da 2 sec e da 4 sec e pwelch con e
%senza overlap. Alla fine si è deciso di prendere brani da 2 sec per essere
%sicuri di rientrare nell'ipotesi di WSS e di non fare overlap di modo che
%i campioni fossero tutti indipendenti tra di loro, permettendo delle
%valutazioni statistiche.

fsamp = 500;
eeg_channel = 4;                      % Canali utilizzati per l'EEG
minuti = 26;                          % Minuti di acquisizione
data_filt = zeros(length(data),5);    % Sui primi 5 canali ci sono O1,O2,F3,F4, ECG
IAF = 10.5;                           % Valore da cambiare di volta in volta (l'IAF va calcolato prima e dopo ogni sessione di training)


%FILTRAGGIO PASSA-BANDA 4-40HZ    
fNy = fsamp/2;
ft1=4;                                %Tagliamo via gli artefatti in bassa frequenza
ft2 = 40;
Wn=[ft1/fNy ft2/fNy];
[B,A] = cheby1(6,0.5,Wn);
%freqz(B,A,512,512);

Palfa=zeros((length(data)/1000),eeg_channel);   %in ogni riga n-esima ci sarà il valore della potenza di banda relativa al blocco da due secondi n-esimo
Pbeta=zeros((length(data)/1000),eeg_channel); 

for ii = 1:eeg_channel
    data_filt(:,ii) = filtfilt(B,A,data(:,ii));
    data_filt(:,ii) = data_filt(:,ii) - mean(data_filt(:,ii));
    
  
    for jj = 1:(minuti*60)/2    %va fatto un ciclo for per metà dei secondi di tutto il segnale, perchè li elaboro a 2 a 2
        signal = data_filt(2*(jj-1)*500+1:2*jj*500, ii);

        T=length(signal)/fsamp;     %durata del brano di segnale in secondi
        ris_teorica=1/T;
        NFFT = fsamp*T;
        window = length(signal);
        [signal_fft(:,ii),f(:,ii)] = pwelch(signal, hamming(window), 0 , NFFT, fsamp);    %no overlap per quanto detto sopra
        
% Le variabili Palfa, Pbeta, e BAR contengono sulle righe il
% valore dell'indice nel rispettivo blocco da 2 secondi e sulle colonne il
% rispettivo canale di acquisizione. In sostanza ad ogni colonna
% corrisponde l'andamento dell'indice nel tempo per un singolo canale. In
% totale si ottengono 780 valori.
        
        fft=signal_fft(:,ii);
        power=sum(fft);
        alpha(jj,ii)=sum(fft(find(f(:,ii)>=7 & f(:,ii)<14)));    %potenza alpha relativa
        Palfa(jj,ii)=alpha(jj,ii)/power;
        beta(jj,ii)=sum(fft(find(f(:,ii)>=14 & f(:,ii)<30)));    %potenza beta relativa
        Pbeta(jj,ii)=beta(jj,ii)/power;
        BAR(jj,ii) = beta(jj,ii)/alpha(jj,ii);                   %BAR= beta/alpha
        asymmetry(jj,1) = (log(Palfa(jj,4))-log(Palfa(jj,3)));   %FAA= ln(F4)-ln(F3)
    end
end


%% Plot dell'andamento dei parametri estratti
%plot dell'andamento del BAR sui 4 canali. Inserisco nel plot delle linee
%di demarcazione di inizio e fine di ogni fase, basate sui marker.


%calcolo i valori delle ascisse del grafico (rispetto ai 780 valori
%di BAR) a cui corrispondono gli attimi di inzio e fine di ogni fase

campioni = 30;                           %numero di valori di BAR ottenuti in 1 min
x1 = start_baseline1/(500*60)*campioni;  %--> dovrebbe essere nei primissimi campioni
xx1 = end_baseline1/(500*60)*campioni;   %--> dovrebbe essere intorno a 45
x2 = start_stresstest/(500*60)*campioni; %--> dovrebbe essere dopo il 45
xx2 = end_stresstest/(500*60)*campioni;  %--> dovrebbe essere intorno a 90
x3 = start_relax/(500*60)*campioni;      %--> dovrebbe essere dopo il 90
xx3 = end_relax/(500*60)*campioni;       %--> dovrebbe essere intorno a 315
x4 = start_baseline2/(500*60)*campioni;  %--> dovrebbe essere dopo 315
xx4 = end_baseline2/(500*60)*campioni;   %--> dovrebbe essere intorno a 360

%plot per visualizzare sullo stesso grafico il BAR, la potenza alpha e la potenza beta
% figure()
% subplot(4,1,1), plot(BAR(:,1)), hold on, plot(Palfa(:,1)), hold on, plot(Pbeta(:,1)), xline(x1, '-g', {'Inizio Baseline1'}), xline(xx1, '-g', {'Fine Baseline1'}), xline(x2, '-r', {'Inizio Stress'}), xline(xx2, '-r', {'Fine Stress'}), xline(x3, '-b', {'Inizio Relax'}), xline(xx3, '-b', {'Fine Relax'}), xline(x4, '-g', {'Inizio Baseline2'}), xline(xx4, '-g', {'Fine Baseline2'}), axis ([0 length(BAR(:,1)) 0 3]), title('BAR su O1'), legend("BAR", "\alpha", "\beta");
% subplot(4,1,2), plot(BAR(:,2)), hold on, plot(Palfa(:,2)), hold on, plot(Pbeta(:,2)), xline(x1, '-g', {'Inizio Baseline1'}), xline(xx1, '-g', {'Fine Baseline1'}), xline(x2, '-r', {'Inizio Stress'}), xline(xx2, '-r', {'Fine Stress'}), xline(x3, '-b', {'Inizio Relax'}), xline(xx3, '-b', {'Fine Relax'}), xline(x4, '-g', {'Inizio Baseline2'}), xline(xx4, '-g', {'Fine Baseline2'}), axis ([0 length(BAR(:,1)) 0 3]), title('BAR su O2'), legend("BAR", "\alpha", "\beta");
% subplot(4,1,3), plot(BAR(:,3)), hold on, plot(Palfa(:,3)), hold on, plot(Pbeta(:,3)), xline(x1, '-g', {'Inizio Baseline1'}), xline(xx1, '-g', {'Fine Baseline1'}), xline(x2, '-r', {'Inizio Stress'}), xline(xx2, '-r', {'Fine Stress'}), xline(x3, '-b', {'Inizio Relax'}), xline(xx3, '-b', {'Fine Relax'}), xline(x4, '-g', {'Inizio Baseline2'}), xline(xx4, '-g', {'Fine Baseline2'}), axis ([0 length(BAR(:,1)) 0 3]), title('BAR su F3'), legend("BAR", "\alpha", "\beta");
% subplot(4,1,4), plot(BAR(:,4)), hold on, plot(Palfa(:,4)), hold on, plot(Pbeta(:,4)), xline(x1, '-g', {'Inizio Baseline1'}), xline(xx1, '-g', {'Fine Baseline1'}), xline(x2, '-r', {'Inizio Stress'}), xline(xx2, '-r', {'Fine Stress'}), xline(x3, '-b', {'Inizio Relax'}), xline(xx3, '-b', {'Fine Relax'}), xline(x4, '-g', {'Inizio Baseline2'}), xline(xx4, '-g', {'Fine Baseline2'}), axis ([0 length(BAR(:,1)) 0 3]), title('BAR su F4'), legend("BAR", "\alpha", "\beta");

t = 1:2:1560;      

%plot per visualizzare l'andamento del BAR nel corso della sessione di training
figure()
subplot(4,1,1), plot(t,BAR(:,1)), xline(x1, '-g', {'Start BS1'}), xline(2*xx1, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}), xline(2*xx2, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}), xline(2*xx3, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}), xline(2*xx4, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), axis ([0 1560 0 4.5]), title('BAR Channel: O1'), ylabel("BAR"), xlabel('Time [s]');
subplot(4,1,2), plot(t,BAR(:,2)), xline(x1, '-g', {'Start BS1'}), xline(2*xx1, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}), xline(2*xx2, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}), xline(2*xx3, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}), xline(2*xx4, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), axis ([0 1560 0 4.5]), title('BAR Channel: O2'), ylabel("BAR"), xlabel('Time [s]');
subplot(4,1,3), plot(t,BAR(:,3)), xline(x1, '-g', {'Start BS1'}), xline(2*xx1, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}), xline(2*xx2, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}), xline(2*xx3, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}), xline(2*xx4, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), axis ([0 1560 0 4.5]), title('BAR Channel: F3'), ylabel("BAR"), xlabel('Time [s]');
subplot(4,1,4), plot(t,BAR(:,4)), xline(x1, '-g', {'Start BS1'}), xline(2*xx1, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}), xline(2*xx2, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}), xline(2*xx3, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}), xline(2*xx4, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), axis ([0 1560 0 4.5]), title('BAR Channel: F4'), ylabel("BAR"), xlabel('Time [s]');

%plot per visualizzare l'andamento dell'asimmetria (FAA) nel corso della sessione di training
figure(), plot(t,asymmetry), xline(x1, '-g', {'Start BS 1'}), xline(2*xx1, '-g', {'End BS 1'}, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}), xline(2*xx2, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}), xline(2*xx3, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}), xline(2*xx4, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), axis([0 1560 -1.5 1.5]), title('Frontal alpha asymmetry'), ylabel("Voltage ln(\muV^2/Hz)"), xlabel('Time [s]');


%% Rilevazione outlier e sostituzione degli stessi con media dei campioni precedenti (Asimmetria)

%Gli outlier, sia per BAR che per Asymmetry, vengono identificati utilizzando il metodo della MAD (Median
%Absolute Deviation): ogni 30 campioni, a passi di 1 campione, viene calcolata la mediana dei
%residui e viene sottratta ad ogni valore storico. Vengono calcolati i
%valori assoluti di queste differenze e viene estratta una nuova mediana
%moltiplicando la mediana originale per una costante empiricamente
%determinata. Questa nuova mediana, trovata automaticamente dal comando "mad",
%è la MAD e viene utilizzata per settare una soglia al di sopra della quale si individuano gli outlier.
%Di norma i valori al di sopra di 4*MAD vengono considerati outlier. Per
%rendere la condizione più restrittiva, la soglia è stata settata a 3*MAD
%per quanto riguarda l'asimmetria, mentre per il BAR verrà mantenuta 4*MAD.
%Nel caso della asimmetria, poichè questo valore può assumere sia valori
%positivi che negativi, il controllo viene effettuato sia per +3MAD che per -3MAD

vector = [];     % Ad ogni ciclo viene reinizializzato il vettore che conterra' gli
                 % indici degli outlier

figure(), plot(t,asymmetry), xline(x1, '-g', {'Start BS1'}), xline(2*xx1, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}), xline(2*xx2, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}), xline(2*xx3, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}), xline(2*xx4, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), axis([0 1560 -1.5 1.5]), title('Frontal Alpha asymmetry'), ylabel("Voltage ln(\muV^2/Hz)"), xlabel('Time [s]');

k=round(x1)+30;
for j=round(x1)+30:length(asymmetry)
    control = mad(asymmetry(j-29:j)); 
    soglia(k)= 3*control;
     k=k+1;
    if asymmetry(j) > 3*control || asymmetry(j) < -3*control
        vector = [vector j];
        hold on, plot(2*j, asymmetry(j), '*k')    % con * vengono indicati gli outlier trovati
    end
    
end
hold on, plot(1:2:1560,soglia, 'k', 'LineWidth',1);
hold on, plot(1:2:1560, -soglia, 'k', 'LineWidth',1);

for j = 1:length(vector)
    asymmetry(vector(j))= mean(asymmetry(vector(j)-4:vector(j)));  %sostituzione degli outlier trovati con la media di se stesso più i 4 campioni precedenti
end


%plot della asimmetria dopo la rimozione degli outlier
figure()
plot(t,asymmetry), xline(x1, '-g', {'Start BS1'}), xline(2*xx1, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}), xline(2*xx2, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}), xline(2*xx3, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}), xline(2*xx4, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), axis([0 1560 -1.5 1.5]), title('Frontal asymmetry'), ylabel("Voltage ln(\muV^2/Hz)"), xlabel('Time [s]');

%% Si rende l'asimmetria più smooth
for j=1:length(asymmetry)
     if j>=5
         asymmetry_smooth(j)=mean(asymmetry(j-4:j));  %si calcola una asimmetria smoothata facendo la media ogni 5 campioni
     end
end
figure()
plot(t,asymmetry_smooth), xline(x1, '-g', {'Start BS1'}), xline(2*xx1, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}), xline(2*xx2, '-r', {'End Stress'}), xline(2*x3, '-b', {'Start Relax'}), xline(2*xx3, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}), xline(2*xx4, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), axis([0 1560 -1.5 1.5]), title('Frontal asymmetry smooth'), ylabel("Voltage ln(\muV^2/Hz)"), xlabel('Time [s]');

%% Rilevazione outlier e sostituzione degli stessi con media dei campioni precedenti (BAR)

%Il procedimento è uguale a quello fatto sull'asimmetria
numero = [];
channel_name = ["O1"; "O2"; "F3"; "F4"]; 
figure()
 for i=1:eeg_channel     
    % Ad ogni ciclo viene reinizializzato il vettore che conterra' gli
    % indici degli outlier del rispettivo canale
    vector = [];
    subplot(4,1,i), plot(t,BAR(:,i)), hold on, xline(x1, '-g', {'Start BS 1'}, 'LineWidth', 2), xline(2*xx1, '-g', {'End BS 1'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}, 'LineWidth', 2), xline(2*xx2, '-r', {'End Stress'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}, 'LineWidth', 2), xline(2*xx3, '-b', {'End Relax'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS 2'}, 'LineWidth', 2), xline(2*xx4, '-g', {'End BS 2'}, 'LineWidth', 2), axis ([0 1560 0 5]), title(sprintf('BAR Channel: %s', channel_name(i))), ylabel("BAR"), xlabel('Time [s]');
    
    %Individuazione degli outlier
    k=round(x1)+30;
    for j=round(x1)+30:length(BAR(:,i))
        control = mad(BAR(j-29:j, i));
         soglia(k,i)= 4*control;
         k=k+1;
        if BAR(j,i) > 4*control
            vector = [vector j];
            hold on, plot(2*j, BAR(j,i), '*k')
        end
    end
    
    hold on, plot(1:2:1560,soglia(:,i), 'k', 'LineWidth',1); 

    % Sostituzione degli outlier con la media di se stesso più i 4 campioni
    % precedenti
    for j = 1:length(vector)
        BAR(vector(j),i)=mean(BAR(vector(j)-4:vector(j),i));
    end
    hold off
    numero(i) = length(vector);
 end
 
     
figure()
subplot(4,1,1), plot(t,BAR(:,1)), xline(x1, '-g', {'Start BS1'}, 'LineWidth', 2), xline(2*xx1, '-g', {'End BS1'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}, 'LineWidth', 2), xline(2*xx2, '-r', {'End Stress'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}, 'LineWidth', 2), xline(2*xx3, '-b', {'End Relax'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}, 'LineWidth', 2), xline(2*xx4, '-g', {'End BS2'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), axis ([0 1560 0 4.5]), title('BAR without outlier Channel: O1'), ylabel("BAR"), xlabel('Time [s]');
subplot(4,1,2), plot(t,BAR(:,2)), xline(x1, '-g', {'Start BS1'}, 'LineWidth', 2), xline(2*xx1, '-g', {'End BS1'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}, 'LineWidth', 2), xline(2*xx2, '-r', {'End Stress'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}, 'LineWidth', 2), xline(2*xx3, '-b', {'End Relax'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}, 'LineWidth', 2), xline(2*xx4, '-g', {'End BS2'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), axis ([0 1560 0 4.5]), title('BAR without outlier Channel: O2'), ylabel("BAR"), xlabel('Time [s]');
subplot(4,1,3), plot(t,BAR(:,3)), xline(x1, '-g', {'Start BS1'}, 'LineWidth', 2), xline(2*xx1, '-g', {'End BS1'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}, 'LineWidth', 2), xline(2*xx2, '-r', {'End Stress'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}, 'LineWidth', 2), xline(2*xx3, '-b', {'End Relax'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}, 'LineWidth', 2), xline(2*xx4, '-g', {'End BS2'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), axis ([0 1560 0 4.5]), title('BAR without outlier Channel: F3'), ylabel("BAR"), xlabel('Time [s]');
subplot(4,1,4), plot(t,BAR(:,4)), xline(x1, '-g', {'Start BS1'}, 'LineWidth', 2), xline(2*xx1, '-g', {'End BS1'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}, 'LineWidth', 2), xline(2*xx2, '-r', {'End Stress'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}, 'LineWidth', 2), xline(2*xx3, '-b', {'End Relax'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}, 'LineWidth', 2), xline(2*xx4, '-g', {'End BS2'}, 'LineWidth', 2, 'LabelHorizontalAlignment', 'left'), axis ([0 1560 0 4.5]), title('BAR without outlier Channel: F4'), ylabel("BAR"), xlabel('Time [s]');


%% BAR SMOOTH
%calcolo un BAR mediato su 10 valori per avere un andamento più smooth (lo
%calcolo a partire dal decimo valore, con i 9 precedenti). Faccio la stessa
%cosa con la potenza alpha e la potenza beta
BAR_smooth=[];
figure()
for i=1:eeg_channel
    for j=1:length(BAR(:,1))
        if j>=10
            BAR_smooth(j,i) = mean(BAR(j-9:j, i));
            Palfa_smooth(j,i) = mean(Palfa(j-9:j, i));
            Pbeta_smooth(j,i) = mean(Pbeta(j-9:j, i)); 
        end
    end
    
    subplot(4,1,i), plot(t,BAR_smooth(:,i)), xline(x1, '-g', {'Start BS1'}), xline(2*xx1, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(2*x2, '-r', {'Start Stress'}), xline(2*xx2, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(2*x3, '-b', {'Start Relax'}), xline(2*xx3, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(2*x4, '-g', {'Start BS2'}), xline(2*xx4, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), axis ([0 1560 0 4.5]), title(sprintf('BAR smooth Channel: %s', channel_name(i))), ylabel("BAR"), xlabel('Time [s]');

end

%% Boxplot del BAR non smooth (ma senza outlier) durante le varie fasi della sessione di training
% Fa un grafico su tutti i canali nei quali mette in ogni
% boxplot una fase: baseline iniziale (minuto centrale), stress test (minuto centrale), i minuti di relax
% scelti (nel nostro caso minuti 1, 5, 10 e 15) e baseline finale (minuto centrale).
% Per usarlo bisogna scegliere i minuti di relax nella variabile 'minuti' e
% rinominare il 'Labels' del boxplot
boxplot_BAR = [];

figure()
for i = 1:eeg_channel
    boxplot_BAR = [boxplot_BAR BAR(campioni+1:2*campioni+1,i)];  %si prende il minuto centrale della fase di Baseline 1
    boxplot_BAR = [boxplot_BAR BAR(campioni*4:campioni*5,i)];    %si prende il minuto centrale della fase di Stress test
    minuti = [1, 5, 10, 14];
    for j = 1:length(minuti)
        boxplot_BAR = [boxplot_BAR, (BAR(round(x3)+minuti(j)*campioni:round(x3)+(minuti(j)+1)*campioni,i))];
    end

    boxplot_BAR = [boxplot_BAR, BAR(round(x4)+campioni:round(x4)+campioni*2,i)];  %si prende il minuto centrale della fase di Baseline 2
    
    subplot(2,2,i),boxplot(boxplot_BAR(:, (3+j)*(i-1)+1:(3+j)*i),'Labels',{'Baseline 1', 'Stress test','Relax: Minute 1', 'Relax: Minute 5', 'Relax: Minute 10', 'Relax: Minute 15', 'Baseline 2'}), title(sprintf('BAR trend over the whole training: Channel %s', channel_name(i))), ylabel('BAR'), xlabel('Training Phase')
end

%% BOXPLOT Asimmetria non smooth (ma senza outlier) durante le varie fasi della sessione di training
channel_name = ["O1"; "O2"; "F3"; "F4"]; 
boxplot_as = [];
boxplot_as(:,1) = asymmetry(campioni+1:2*campioni+1);  %si prende il minuto centrale della fase di Baseline 1
boxplot_as(:,2) = asymmetry(campioni*4:campioni*5);    %si prende il minuto centrale della fase di Stress test
minuti = [1, 5, 10, 14];
for j = 1:length(minuti)
    boxplot_as = [boxplot_as, (asymmetry(round(x3)+minuti(j)*campioni:round(x3)+(minuti(j)+1)*campioni))];
end
boxplot_as = [boxplot_as, asymmetry(round(x4)+campioni:round(x4)+campioni*2)];  %si prende il minuto centrale della fase di Baseline 2

figure(), boxplot(boxplot_as,'Labels',{'Baseline', 'Stress test','Primo minuto relax', 'Quinto minuto relax', 'Decimo minuto relax', 'Ultimo minuto relax', 'Seconda baseline'}), title(sprintf('Asymmetry over the whole training session')), ylabel("Voltage ln(\muV^2/Hz)"), xlabel('training Phases')

%% Boxplot BAR tra baseline iniziale e baseline finale
figure()
for i = 1:eeg_channel
    boxplot_baseline_3(:,(i-1)*2+1) = BAR(campioni+1:2*campioni+1,i);
    boxplot_baseline_3(:,2*i) = BAR(round(x4)+campioni:round(x4)+(campioni*2),i);
    subplot(2,2,i), boxplot(boxplot_baseline_3(:,(i-1)*2+1:2*i),'Labels',{'Prima baseline','Seconda baseline'}), title(sprintf('Baseline Channel %d: %s', i, channel_name(i)))  
end




%% Calcolo di TItR, Max Relaxation Score (MRS) e Tmax
% TItR: primo istante di tempo in cui si verifica la condizione che il
% soggetto riesce a mantenere il suo BAR sotto una soglia fissa
% predeterminata per 20 secondi.
% MRS: minimo valore di BAR raggiunto nella sessione di training mantenuto
% consecutivamente per 10 secondi nel range del suo +-5%
% Tmax: tempo massimo per cui il soggetto riesce a mantenere il BAR sotto
% soglia consecutivamente
%Questi 3 valori vengono calcolati sul BAR smooth



% Per il calcolo del Ttir si stabilisce una soglia pari a 0.6 per il soggetto in questione,
% prendiamo il primo campione per il quale il valore di BAR si mantiene
% sottosoglia per i successivi 20 secondi (10 campioni).
% 0.6 e' un valore che viene sempre raggiunto in ogni sessione di training e che sia
% vicino ai valori minimi raggiunti. E' stato stabilito come l'80% del BAR
% medio ottenuto nella prima sessione di training
k = 1;
for i=round(x3):round(xx3)-11
    if BAR_smooth(i:i+11,1) < 0.6
        Ttir_sec = (2*(i-round(x3)))              % TItR in secondi
        Ttir_min = (2*(i-round(x3)))/60           % TItR in minuti
        Ttir = i                                  %TItR in campioni
        break
    end
end

% Per il calcolo del MRS abbiamo valutato il valore del
% BAR minimo che si mantenesse per 10 secondi (5 campioni) nel range del
% suo +- 5%, prendiamo poi il minimo del range nel quale si verifica la
% condizione di stabilita', dopodiche' calcoliamo il MRS
% come il minimo tra tutti i minimi 

% In questo caso, rispetto al caso del TItR, vengono valutati i campioni
% precedenti rispetto al campione in analisi. Questo avviene per far sì di
% essere sicuri di prendere in analisi campioni che sono sempre nella fase
% di relax o al più nella fase di intermezzo tra stress e relax. 

for i = round(x3):round(xx3)
    high = BAR_smooth(i,1) + BAR_smooth(i,1)*0.05;    %soglia di BAR + 5%
    low = BAR_smooth(i,1) - BAR_smooth(i,1)*0.05;     %soglia di BAR - 5%
    if ((BAR_smooth(i-4:i,1)) < high)
        if ((BAR_smooth(i-4:i,1)) > low)
            minimo(k) = min(BAR_smooth(i-4:i,1));
            k = k + 1;
        end
    end
end
max_relaxation_score = min(minimo)

%Per il calcolo del Tmax è necessario un ciclo while che continua a
%controllare fino a che indice il BAR si mantiene sotto la soglia 0.6.
%Vengono trovati diversi intervalli che soddisfano la condizione, per cui
%si prende come Tmax il maggiore di questi
t_max = [];
for i = round(x3):round(xx3)
    if ((BAR_smooth(i-4,1)) < 0.6)
        k = 1; 
        while (BAR_smooth(i-4+k, 1) < 0.6)
            k = k + 1;
            if (i-4+k) > round(xx3)     %viene fatto un check: se si va oltre la fase del relax si esce
                break
            end
        end
        t_max = [t_max; k];
    end
end

t_max_absolute = max(t_max)


%% SEGNALE ECG: Filtraggio, rilevazione dei picchi RR, calcolo della durata degli intervalli RR e relativi parametri statistici 

% Per la valutazione dell'ECG i parametri vengono estratti ogni 30 secondi

ecg = data(:,5);        %l'ecg si trova sul ch5 del dato importato dal NIC
figure()
plot(ecg(:,1)), axis([1 26*60*500 -0.5e08 0.2e07]), title ('ecg dato grezzo')

ft1=4;
ft2=100;
Wp=[ft1/fNy ft2/fNy];
R=0.5;
N=8;    
[b,a]=cheby1(N,R,Wp,'bandpass');
figure()
% freqz(b,a,256,fsamp);
ecg_filt=filtfilt(b,a,ecg);
figure()
plot(ecg_filt(:,1)),axis([1 26*60*500 -1e06 1e06]), title ('ecg filtrato')
minuti = 26;            %si ridefiniscono i minuti dell'intera sessione di training


%Definizione delle variabili globali: ogni variabile avrà due elementi per
%ogni minuto della sessione di training, quindi sarà costituita da 26*2
%sottovariabili (dato che i valori sono campionati ogni 30 secondi)

global PEAKS       %variabile che conterrà i valori dei picchi R          
PEAKS = string(minuti*2);
global LOCKS       %variabile che conterrà le posizioni dei picchi R
LOCKS = string(minuti*2);
global RR          %variabile che conterrà le durate degli intervalli RR
RR = string(minuti*2);
global SDNN        %variabile che conterrà la Standard Deviation Normal to Normal (è un indice della Heart Rate Variability (HRV))
SDNN = string(minuti*2);
global RMSSD       %variabile che conterrà la Root Mean Square of the Successive Differences (è un indice della Heart Rate Variability (HRV))
RMSSD = string(minuti*2);
for jj = 1:minuti*2
    PEAKS(jj) = strcat('pk',num2str(jj));
    LOCKS(jj) = strcat('lk',num2str(jj));
    RR(jj) = strcat('RR',num2str(jj));
    SDNN(jj) = strcat('SDNN',num2str(jj));
    RMSSD(jj) = strcat('RMSSD',num2str(jj));
end

for jj = 1:minuti*2
    signal = ecg_filt(30*(jj-1)*500+1:30*jj*500);
    [pks,locs] = findpeaks(signal,'MinPeakDistance', 220, 'MinPeakHeight',30000);   %identificazione dei picchi R
  %  plot(ecg_filt), hold on, plot(LOCS,PKS, 'o'), title(sprintf('ECG minuto %d', jj));


ECG.PEAKS.(PEAKS{jj})=pks;     %nella struct ECG ci sono due sottostruct, ognuna contiene i peaks e i locs minuto per minuto
ECG.LOCKS.(LOCKS{jj})=locs;
HR_plot(jj) = 2*length(pks);

%inseriamo all'interno di RR le durate dei (locks-1) intervalli per ogni minuto

lunghezza=length(ECG.LOCKS.(LOCKS{jj}));
ECG.RR.(RR{jj})=zeros(1,lunghezza-1);
for a=1:lunghezza-1
    ECG.RR.(RR{jj})(1,a)=(abs(ECG.LOCKS.(LOCKS{jj})(a+1)-ECG.LOCKS.(LOCKS{jj})(a)))/fsamp;  %durata RR in secondi
end

end

%% statistica ecg
for jj=1:minuti*2
    % SDNN: Standard deviation of the normal-to-normal interval
    %E' la deviazione standard degli intervalli NN (RR) totali: mostra il
    %livello di variazione dell'HR durante l'acquisizione. Un decremento di
    %questo parametro indica un aumento del livello di stress.
    %In fase finale si è deciso di non considerare questo parametro perchè
    %non adatto a questo studio, ma maggiormente adatto a registrazioni ECG
    %prolungate (es: Holter)
    ECG.SDNN.(SDNN{jj})=std(ECG.RR.(RR{jj}));
    SDNN_plot(jj) = std(ECG.RR.(RR{jj}));
    
    % RMSSD: Root Mean Square of the successive differencies
    % E' il valore quadratico medio della differenza tra due intervalli NN
    % adiacenti; mostra un cambiamento nel battito cardiaco in un periodo breve
    % di tempo. Un incremento di questo parametro determina un decremento del
    % livello di stress.
    y = 0;
    for ii = 1:length(ECG.RR.(RR{jj}))-1
        x = (ECG.RR.(RR{jj})(ii+1)-ECG.RR.(RR{jj})(ii))^2;
        y = y + x;
    end
   ECG.RMSSD.(RMSSD{jj})= sqrt((y)/length(ECG.RR.(RR{jj})));
   RMSSD_plot(jj) = sqrt((y)/length(ECG.RR.(RR{jj})));
end

%plot degli andamenti di HR e RMSSD durante l'intera sessione di training
x_axis = 0.5:0.5:26;
x_axis_2 = 1:26*2;
figure()
subplot(211), plot(x_axis, RMSSD_plot), hold on, plot(x_axis, RMSSD_plot, '.', 'MarkerSize', 20), xline(0.5, '-g', {'Start BS1'}), xline(3, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(3.5, '-r', {'Start Stress'}), xline(6.5, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(7, '-b', {'Start Relax'}), xline(21.5, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(22, '-g', {'Start BS2'}), xline(25, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), xlabel('Time [min]'), ylabel('Variability [s]'), axis([0 26 0 0.2]), title('RMSSD')
set(gca,'xtick', [1:26], 'FontSize', 14)
subplot(212), plot(x_axis, HR_plot), hold on, plot(x_axis, HR_plot, '.', 'MarkerSize', 20), xline(0.5, '-g', {'Start BS1'}), xline(3, '-g', {'End BS1'}, 'LabelHorizontalAlignment', 'left'), xline(3.5, '-r', {'Start Stress'}), xline(6.5, '-r', {'End Stress'}, 'LabelHorizontalAlignment', 'left'), xline(7, '-b', {'Start Relax'}), xline(21.5, '-b', {'End Relax'}, 'LabelHorizontalAlignment', 'left'), xline(22, '-g', {'Start BS2'}), xline(25, '-g', {'End BS2'}, 'LabelHorizontalAlignment', 'left'), xlabel('Time [min]'), ylabel('Frequency [bpm]'), axis([0 26 70 105]), title('HR')
set(gca,'xtick', [1:26], 'FontSize', 14)

%% Parametri per i confronti tra i vari training 

HRV_max = max(RMSSD_plot(14:43))
[HR_min, index] = min(HR_plot(14:43))
HR = [];
index = [];

% Il primo parametro calcolate ma che poi effettivamente non è stato
% utilizzato è il tempo necessario affinchè il paziente raggiungere un HR
% minimo che si mantenesse per almeno un minuto.

for ii = 14:43-1
    if HR_plot(ii) == HR_plot(ii + 1)
        HR = [HR HR_plot(ii)];
        index = [index ii];
    end
end

[HR_min, indice] = min(HR);
TiTr_ECG = (index(indice) - 14)/2


% Il secondo parametro invece è il primo istante di tempo in cui il
% paziente riesce a mantenere il battito cardiaco sotto gli 86 battiti per
% almeno 2 minuti e mezzo 

for ii = 14:43-1
    if HR_plot(ii:ii+4) <= 86
        TiTr_ECG_soglia = (ii - 14)/2
        break
    end
end

%% Si fa un test di Student tra i valori di HR e di HRV delle varie fasi
% per capire se c'è differenza statisticamente significativa
HR_bs1 = HR_plot(1:6);
HR_st = HR_plot(7:13);
HR_rlx = HR_plot(28:43);
HR_bs2 = HR_plot(44:50);

RMSSD_bs1 = RMSSD_plot(1:6);
RMSSD_st = RMSSD_plot(7:13);
RMSSD_rlx = RMSSD_plot(28:43);
RMSSD_bs2 = RMSSD_plot(44:50);

[h_HR_bs,p_HR_bs] = ttest2(HR_bs1, HR_bs2);
[h_HR_sr,p_HR_sr] = ttest2(HR_st, HR_rlx);
[h_RMSSD_bs,p_RMSSD_bs] = ttest2(RMSSD_bs1, RMSSD_bs2);
[h_RMSSD_sr,p_RMSSD_sr] = ttest2(RMSSD_st, RMSSD_rlx);