%% Normalizzazione dei valori del BAR con la mediana della prima baseline per tutti i training, NON LANCIARE

% Vengono confrontati i parametri estratti dall'EEG in una finestra
% temporale per tutte le varie fasi del training: ogni campione corrisponde
% ad una finestra temporale di 2 secondi, 

% Creazione delle variabili, questa parte di codice NON va lanciata, serve
% per calcolare la matrice contentente i valori dei parametri EEG
% concatenati sui vari training, per ottenerla bisognerebbe lanciare questa
% sezione per ogni training considerato facendo attenzione alle ultime 
% righe di codice di questa sezione

% Nel caso dei confronti statistici in questione, per il calcolo dei
% boxplot, sono stati eliminati i seguenti training

% Training da 1 a 3: Utilizzo della prima Baseline
% Training del 17 Febbraio: Escluso per conteggio mattonelle nella
% prima baseline
% Training del 21: Orali durante le prove

% Vanno quindi presi solo i training del 13 15 20 22 Febbraio.

% Forniamo come .mat le matrici di dati già calcolate da noi come appena
% descritto, basta caricare quelle per ottenere i grafici. 


for i = 1:7
    boxplot_BAR_(:,i) = boxplot_BAR(:,i) / median(boxplot_BAR(:,1));
end

for i = 8:14
    boxplot_BAR_(:,i) = boxplot_BAR(:,i) / median(boxplot_BAR(:,8));
end

for i = 15:21
    boxplot_BAR_(:,i) = boxplot_BAR(:,i) / median(boxplot_BAR(:,15));
end

for i = 22:28
    boxplot_BAR_(:,i) = boxplot_BAR(:,i) / median(boxplot_BAR(:,22));
end

% Normalizzazione per la mediana del primo training e concatenazione  dei vari training per l'asimmetria

for i = 1:7
    boxplot_as_(:,i) = boxplot_as(:,i) / abs(median(boxplot_as(:,1)));
end

% Matrici per confronti asimmetria tra Stress test e Relax 

As_stress = asymmetry(round(x2):round(x2) + 90)  / abs(median(boxplot_as(:,1)));
As_relax = asymmetry(420:510) / abs(median(boxplot_as(:,1)));

% Da lanciare per il primo training in analisi 
% boxplot_training_totali = boxplot_BAR_;
% boxplot_as_totali = boxplot_as_;
% As_stress_totale = As_stress;
% As_relax_totale = As_relax;

% Da lanciare per tutti gli altri training in analisi
boxplot_training_totali = [boxplot_training_totali ; boxplot_BAR_];
boxplot_as_totali = [boxplot_as_totali ; boxplot_as_];
As_stress_totale = [As_stress_totale; As_stress];
As_relax_totale = [As_relax_totale; As_relax];


%% CARICAMENTO DEI DATI DA USARE

load('boxplot_training_totali')
load('boxplot_as_totale')
load('As_relax_totale')
load('As_stress_totale')

%% Confronti statistici su Baseline e grafici

[h1,p1] = ttest2(boxplot_training_totali(:,1), boxplot_training_totali(:,7))
[h2,p2] = ttest2(boxplot_training_totali(:,8), boxplot_training_totali(:,14))

%% Boxplot due baseline

figure()
subplot(121), boxplot([boxplot_training_totali(:,1) boxplot_training_totali(:,7)], 'Labels', {'Baseline 1', 'Baseline2'}), title('BAR trend over the two baselines: Channel O1'), xlabel('Training Phases'), ylabel('BAR')
subplot(122), boxplot([boxplot_training_totali(:,8) boxplot_training_totali(:,14)], 'Labels', {'Baseline 1', 'Baseline2'}), title('BAR trend over the two baselines: Channel O2'), xlabel('Training Phases'), ylabel('BAR')

%% Confronti statistici su Baseline e grafici asimmetria

[h1,p1] = ttest2(boxplot_as_totali(:,1), boxplot_as_totali(:,7))

group = {[1, 2]};
figure(), boxplot([boxplot_as_totali(:,1) boxplot_as_totali(:,7)]), , xlabel('Training Phase'), title('Frontal alpha asymmetry'), ylabel("Voltage ln(\muV^2/Hz)")
sigstar({[1, 2]},p1)
set(gca,'xticklabel',{'Baseline 1','Baseline 2'}, 'FontSize', 14)

%% Confronti statistici su Minuto centrale stress test e ultimo relax e grafici asimmetria - Da eliminare

[h3,p3] = ttest2(boxplot_as_totali(:,2), boxplot_as_totali(:,6))

figure(), plot(boxplot_as_totali(:,2)), hold on, plot(boxplot_as_totali(:,6))
figure(), boxplot([boxplot_as_totali(:,2) boxplot_as_totali(:,6)], 'Labels', {'Stress', 'Relax'}), title('Asimmetry trend over the two baselines'), xlabel('Training Phases'), ylabel('Asimmetry')

%% Confronti statistici dei Asimmetria su stress e relax

[h1,p1] = ttest2(As_stress_totale, As_relax_totale)

figure(), boxplot([As_stress_totale As_relax_totale], 'Labels',{'Stress Test', 'Relax: Minutes 14-17'}), ylabel('Asimmetry'), xlabel('Training Phases'), title('Asimmetry trend over Stress test and Relax phase')
figure(), plot(As_stress_totale), hold on, plot(As_relax_totale)

%% CONFRONTO DELL'ANDAMENTO DEI VARI TRAINING

TitR_EEG_trend = [11 3.27 6.23 7.97 1.97 2.20 4.30 4.03 2.70];
TitR_EEG_trend_s = [660 196 374 478 118 132 258 242 162];
MRS_trend = [0.6314 0.4619 0.4395 0.4888 0.4314 0.2528 0.3846 0.3682 0.4274];
Tmax_trend = [27 44 12 22 60 183 47 174 55]*2;

figure(), plot(TitR_EEG_trend, 'Color',[0.8500 0.3250 0.0980], 'LineWidth', 2), hold on, plot(TitR_EEG_trend, '.', 'Color', [0 0.4470 0.7410], 'MarkerSize', 25), title('TitR EEG'), xlabel('#Training'), ylabel('Time [min]')
figure(), plot(TitR_EEG_trend_s, 'Color',[0.8500 0.3250 0.0980], 'LineWidth', 2), hold on, plot(TitR_EEG_trend_s, '.', 'Color', [0 0.4470 0.7410], 'MarkerSize', 25), title('TitR EEG'), xlabel('#Training'), ylabel('Time [s]')
figure(), plot(MRS_trend, 'Color',[0.8500 0.3250 0.0980], 'LineWidth', 2), hold on, plot(MRS_trend, '.', 'MarkerSize', 20, 'Color', [0 0.4470 0.7410]), title('Max relaxation score in all trainings'), xlabel('#Training'), ylabel('MRS')
figure(), plot(Tmax_trend, 'Color',[0.8500 0.3250 0.0980], 'LineWidth', 2), hold on, plot(Tmax_trend, '.', 'MarkerSize', 20, 'Color', [0 0.4470 0.7410]), title('T_m_a_x'), xlabel('#Training'), ylabel('Time [s]')

%% SCATTER PLOT INDICI 

x = [1 2 3 4 5 6 7 8 9];
X = [ones(length(x),1) x'];
b = X\TitR_EEG_trend'

yCalc1 = X*b;
figure(),scatter(x,TitR_EEG_trend, 'filled')
hold on
plot(x,yCalc1, 'LineWidth', 2), title('TItR'), ylabel('Time [min]'), xlabel('# Training')
set(gca,'FontSize', 12, 'xticklabel', {'1','2','3','4','5','6','7','8','9'})

b = X\MRS_trend'

yCalc1 = X*b;
figure(),scatter(x,MRS_trend, 'filled')
hold on
plot(x,yCalc1, 'LineWidth', 2), title('MRS'), ylabel('BAR'), xlabel('# Training')
set(gca,'FontSize', 12, 'xticklabel', {'1','2','3','4','5','6','7','8','9'})

b = X\Tmax_trend'

yCalc1 = X*b;
figure(),scatter(x,Tmax_trend, 'filled')
hold on
plot(x,yCalc1, 'LineWidth', 2), title('T_m_a_x'), ylabel('Time [s]'), xlabel('# Training')
set(gca,'FontSize', 12, 'xticklabel', {'1','2','3','4','5','6','7','8','9'})



