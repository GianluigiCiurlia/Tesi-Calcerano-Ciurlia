%Script per ricezione in real time dei dati da NIC2, elaborazione in tempo
%reale, estrazione del parametro di feedback e invio di questo parametro in
%real time a Unity.

%Il NIC invia a Matlab i dati in real-time tramite connessione LSL; Matlab
%invia a Unity il parametro di feedback in real-time tramite connessione TCP/IP

clear all

%% Creazione della connessione LSL
% instantiate the library
disp('Loading the library...');     %caricamento della libreria liblsl che permette la connessione
lib = lsl_loadlib();                     

% resolve a stream...
disp('Resolving an EEG stream...');   %ricerca di uno stream in rete
result = {};
while isempty(result)
    result = lsl_resolve_byprop(lib,'type','EEG'); end   %specifica del tipo di dato passato (ricordarsi di abilitare LSL Server sul NIC e specificare "EEG" alla voce "Outlet for Lab Streaming Layer")

% create a new inlet
disp('Opening an inlet...');
inlet = lsl_inlet(result{1});

disp('Now receiving chunked data...');

%% filtraggio del segnale in real time
fsamp = 500;       %f di campionamento del NIC
fNy = fsamp/2;

% Il codice per elaborare i dati ricevuti tramite connessione LSL è basato su di un
% while, creiamo una variabile ii che viene aumentata di 1 ad ogni iterazione. 

ii = 1;

% Il codice calcola le stime spettrali per ogni singolo canale, è necessario
% quindi specificare quanti sono i canali relativi al segnale EEG

eeg_channel = 4;     %O1, O2, F3, F4


%% Creazione della connessione TCP/IP e inizializzazione per inviare i dati a Unity 

%Nel momento dell'inizializzazione è necessario specificare indirizzo IP e la porta. 
%La porta può essere un numero qualsiasi tra 1 e 65000; ogni parametro da modificare nello scenario
%necessita di una nuova connessione, e quindi di una nuova porta
%L'indirizzo IP deve essere 127.0.0.1 nel caso in cui si voglia fare una connessione con il pc stesso,
%ovvero nel caso in cui Matlab e Unity runnino entrambi sullo stesso PC
%Nel caso in cui si voglia fare una connessione con un device esterno bisogna che sia il pc che il device
%siano connessi allo stesso wi-fi ed è necesaria la modifica dell'indirizzo IP
% Per maggiori informazioni consultare il seguente link: https://it.mathworks.com/matlabcentral/answers/196774-connection-between-matlab-and-unity3d

tcpipClient = tcpip('127.0.0.1',55001,'NetworkRole','Client');
set(tcpipClient,'Timeout',30);


%% Concatenazione dei chunk, filtraggio e calcolo della PSD
% Filtraggio passa-banda per selezionare banda alpha e beta del segnale

ft1=4;
ft2 = 40;
Wn=[ft1/fNy ft2/fNy];
[B,A] = cheby1(5,0.5,Wn);
% freqz(B,A,512,512)

while true
%Tramite connessione LSL si possono ricevere dati sia campione per campione sia in pacchetti (chunks), in questo codice si ricevono in chunks

    % get chunk from the inlet
    [chunk,stamps] = inlet.pull_chunk();   
    for s=1:length(stamps)
        % and display it
        fprintf('%.2f\t',chunk(:,s));               %print del valore dei chunk
        fprintf('%.5f\n',stamps(s));
    end

    
% Il primo chunk che arriva è sempre vuoto, quindi iniziamo a creare la
% matrice sulla quale calcoleremo gli indici a partire dalla seconda
% iterazione. In particolare:
% Quando ii == 2 si tratta del primo chunk di dati utile e viene
% semplicemente copiato all'interno di una variabile "signal".
% Nelle iterazioni tra 2 e 5 i chunk vengono concatenati tra loro in
% modo da avere un vettore sul quale fare stima spettrale di circa 1000
% campioni. I chunk che arrivano non è detto che siano sempre di 250
% campioni (dovuto a ritardi nell'elaborazione dei dati), questo
% implica che si avrà una matrice finale dove sulle righe sono
% contenuti i canali EEG mentre sulle colonne avremo il numero di
% campioni concatenati a seguito dei primi 4 chunk arrivati. 
% Nelle iterazioni successive alla quinta vengono messi in coda alla
% matrice i primi N-campioni dove N rappresenta la lunghezza
% dell'ultimo chunk arrivato e sostituiti con i nuovi campioni.  
% In questo modo di hanno sempre blocchi di segnale da circa 1000
% campioni, ottenuti concatenando i chunk man mano che arrivano per non
% perdere informazione.
    

  
    
    if ii == 2
        signal = chunk;
    elseif ii > 2 && ii <= 5
        signal = [signal chunk];
    elseif ii > 5
        signal = circshift(signal, -size(chunk,2), 2);
        if size(chunk,2)> size(signal,2)
            signal=chunk(:,end-size(signal,2):end);
        else
            
        signal(:,end-size(chunk,2)+1:end) = chunk;
        end 
       
    
        for jj = 1:eeg_channel              % La stima spettrale viene effettuata su ogni canale
            signal_ = signal(jj,:);
            signal_mean = filtfilt(B,A,signal_);
            signal_mean = signal_mean - mean(signal_mean);

            T=length(signal_mean)/fsamp;     %durata del brano di segnale in secondi
            ris_teorica=1/T;
            NFFT = fsamp*T;
            window = length(signal_mean)/2;
            [signal_fft,f] = pwelch(signal_mean, hamming(window), 0.5*window , NFFT, fsamp);

% Le variabili Palfa, Pbeta, e BAR contengono sulle colonne il valore dell'indice nel rispettivo
% periodo e sulle righe il rispettivo canale di acquisizione. In sostanza ad ogni riga
% corrisponde l'andamento dell'indice nel tempo per un singolo canale

            power=sum(signal_fft);
            alpha=sum(signal_fft(find(f>=8 & f<14))); 
            Palfa(jj,ii)=alpha/power;                  %potenza relativa in banda alpha
            beta=sum(signal_fft(find(f>=14 & f<30)));
            Pbeta(jj,ii)=beta/power;                   %potenza relativa in banda beta
            BAR(jj,ii) = beta/alpha;                   %calcolo del BAR

% Al fine di avere un indice che sia non eccessivamente variabile
% per fare feedback su Unity abbiamo mediato il BAR con i 3
% valori ottenuti precedentemente in modo da ridurre
% cambiamenti repentini e rendere l'andamento più smooth
            
            if ii >= 4
                BAR_mediato(jj,ii) = mean(BAR(jj, ii-3:ii));
            end
        end    
    end
    
% Invio dei dati da Matlab a Unity (viene fatto all'interno di
% un if che controlla che ii sia maggiore di 4 perché per
% calcolare il BAR mediato abbiamo bisogno di almeno 3 iterazioni
        if ii >= 4
            BAR_mediato_occ = (BAR_mediato(1, ii) + BAR_mediato(2,ii))/2    %viene calcolato un BAR medio tra O1 e O2 da mandare come feedback
            fopen(tcpipClient);  
            c = num2str(BAR_mediato_occ);          %il valore viene convertito in stringa per essere letto da Unity
            fwrite(tcpipClient, c);
            fclose(tcpipClient);
        end
        

    ii = ii + 1;
    
    pause(0.5);      %é stata scelta una pausa di 0.5 di modo che i dati vengano inviati ogni 500 ms, tempistica adatta per il real time.
                     %Questa pausa può essere cambiata a seconda delle esigenze
end