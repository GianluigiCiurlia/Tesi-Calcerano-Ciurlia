%Script per il calcolo della Individual Alpha Frequency (IAF) del soggetto
%Il soggetto indossa l'Oculus spento per 3 minuti, viene calcolata la PSD
%per ogni minuto di acquisizione, e con essa viene plottato il grafico da
%cui si ricaverà la frequenza a cui corrisponde il picco in banda alpha.
%Dai tre picchi visualizzati si sceglie un valore che sia una media dei
%tre, dando però maggiore importanza ai picchi degli ultimi due minuti.

clear all
close all
clc

%% Caricamento del segnale e filtraggio

signal = load ('IAF_Giangi_15_febbraio_strobo3.easy'); 

Pz = signal(:,3);           %Pz, dalla letteratura, risulta essere il canale su cui visualizzare meglio il picco alpha.
fsamp=500;                  % frequenza di campionamento del NIC2

%FILTRAGGIO PASSA-BANDA 3-40HZ
fNy = fsamp/2;
ft1=3;
ft2 = 40;

Wn=[ft1/fNy ft2/fNy];
N=3;
[B,A] = cheby1(6,0.5,Wn);
freqz(B,A,512,512);

Pz_filt= filtfilt(B,A,Pz);
Pz_filt = Pz_filt - mean(Pz_filt);

%divisione del segnale nei tre minuti
Pz_1=Pz_filt(1:60*1*500);               
Pz_2=Pz_filt(60*1*500+1:60*2*500);
Pz_3= Pz_filt(60*2*500+1:60*3*500);


%% Calcolo della PSD e plottaggio
T=length(Pz_1)/fsamp;       %durata del brano di segnale in secondi
ris_teorica=1/T;
NFFT = fsamp*T;
[F4_1_fft,f]=pwelch(Pz_1,hamming(1000), 500, NFFT, fsamp);
[F4_2_fft,f]=pwelch(Pz_2,hamming(1000), 500, NFFT, fsamp);
[F4_3_fft,f]=pwelch(Pz_3,hamming(1000), 500, NFFT, fsamp);

figure()
subplot(3,1,1),plot(f,F4_1_fft/max(F4_1_fft)), title ('FFT F3, minuto 1, primo minuto background')
subplot(3,1,2),plot(f,F4_2_fft/max(F4_2_fft)), title ('FFT F4, minuto 1, primo minuto background')
subplot(3,1,3),plot(f,F4_3_fft/max(F4_3_fft)), title ('FFT O1, minuto 1, primo minuto background')

