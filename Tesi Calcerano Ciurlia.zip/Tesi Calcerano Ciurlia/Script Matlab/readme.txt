Nella cartella sono presenti tutti gli script che al momento utilizziamo e che sono stati usati in precedenza. I file vengono forniti in formato .cs per codici C# e .m.

DESCRIZIONE E UTILIZZO DEI CODICI IN USO

- 'Vibration.cs' è il codice che permette il flickering della luce nell'ambientazione, non è stato implementato da noi ma è stato trovato online. 
  Permette di scegliere ampiezza della variazione, forma d'onda e frequenza. 

- 'FogDensity.cs' è il codice tramite il quale viene modificata la nebbia all'interno dello scenario. Sfrutta una connessione TCP/IP tramite la quale riceve il valore 
  di un indice da un server e modifica l'intensità della nebbia. 

  Per farlo funzionare è necessario che venga modificato l'indirizzo IP:
	- Se si lancia lo script in play mode direttamente da Unity l'indirizzo IP 
	  da inserire è '127.0.0.1'
	- Se si lancia lo script come eseguibile su di un device, l'indirizzo IP 
	  da inserire è quello della connessione internet. 


- 'ReciveDataInChunks.m' è il codice che al momento usiamo per il real time: La ricezione dei dati si basa su di un ciclo while. Riceve i dati in formato chunk, 
  e la dimensione del chunk viene impostata tramite la pausa presente alla fine del while. 
  Vengono elaborati tutti i canali EEG, ed è necessario inserire nella variabile 'eeg_channels' il numero di canali del protocollo.
  Per far partire il codice è necessario che sia acceso NIC e che abbia un protocollo in esecuzione (basta anche un file .easy con segnale già acquisito).
  Per abilitare la connessione LSL da NIC2:
	- Protocol Editor -> Selezionare un nuovo protocollo oppure uno già esistente
	- Settings -> Selezionare la spunta 'LSL' e modificare il campo 'Outlet for Lab Streaming Layer' inserendo 'EEG'
	- Far partire il protocollo e consentire la connessione LSL nel pop-up che esce una volta iniziata l'acquisizione

  Nel caso si voglia far partire lo script ma senza la connessione con Unity è necessario commentare le righe riguardanti la connessione TCP/IP, nel caso in cui si 
  voglia usare anche Unity va modificato l'indirizzo IP in maniera analoga la codice 'FogDensity.cs'

Lo script è presente nel folder: liblsl-Matlab-1.14.0-Win_amd64_R2020b\liblsl-Matlab


SCRIPT CHE NON USIAMO 

- 'MoveAroundObject.cs', trovato online, serve per far ruotare un oggetto in play mode in funzione del movimento del mouse, lo usavamo per far ruotare la camera 
  simulando la rotazione dell'HMD di Oculus

- 'Activation.cs' è un codice che usiamo per attivare o meno una componente dello scenario cliccando un tasto.

- 'NewBehaviourScript.cs' codice con il quale implementavamo il ciclo notte/giorno in funzione dell'EEG. Necessaria modifica dell'indirizzo IP. 

- 'Bar.cs' codice con il quale inserivamo una barra che mostrasse l'andamento del parametro scelto per il feedback in real time.

- 'myPlaySwitch.cs': codice con il quale modificavamo l'intensità della musica in funzione dell'EEG.
	- Bassi indici di rilassamento -> Musica stressante ad alto volume che diminuisce se il paziente si rilassa
	- Alti indici di rilassamento -> Musica rilassante ad alto volume che diminuisce se il paziente si stressa
