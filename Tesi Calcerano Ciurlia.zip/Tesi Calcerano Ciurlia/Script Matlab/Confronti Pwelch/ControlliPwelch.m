%% Confronto con vari periodogrammi

% Questo script serve per fare un confronto tra le varie condizioni provate
% per il calcolo del periodogramma:

% Condizione 1: Finestre di 4 secondi a passi di 4 secondi (esempio: prima finestra 0-4 s, seconda finestra 5-8 s)
% Condizione 2: Finestre di 2 secondi a passi di 2 secondi (esempio: prima finestra 0-2 s, seconda finestra 3-4 s)
% Condizione 3: Finestre di 4 secondi a passi di 2 secondi (esempio: prima finestra 0-4 s, seconda finestra 2-6 s)
% Condizione 4: Finestre di 2 secondi a passi di 1 secondo (esempio: prima finestra 0-2 s, seconda finestra 1-3 s)

load('boxplot_BAR_1.mat')
load('boxplot_BAR_2.mat')
load('boxplot_BAR_4.mat')
load('boxplot_BAR_3.mat')
load('p val overlap.mat')
load('p val no overlap.mat')


%% Boxplot con solo confronto tra le BASELINE
a=[boxplot_BAR_1(:,1), boxplot_BAR_1(:,7)];
b=[boxplot_BAR_3(:,1), boxplot_BAR_3(:,7)];
[h1,p1] = ttest2(boxplot_BAR_1(:,1), boxplot_BAR_3(:,1))
[h2,p2] = ttest2(boxplot_BAR_1(:,7), boxplot_BAR_3(:,7))
X1=[1,2];
% Original
X2=[1.3	2.3];
figure(), subplot(121)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('Without Overlap p1 %d p2 %d',p1, p2))
g = findall(gca,'Tag','Box');
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
g = findall(gca,'Tag','Box');
hold off
set(gca,'xticklabel',{'Baseline 1','Baseline 2'})
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(3), g(1)], {'4 second', '2 second'});


a=[boxplot_BAR_2(:,1), boxplot_BAR_2(:,7)];
b=[boxplot_BAR_4(:,1), boxplot_BAR_4(:,7)];
[h3,p3] = ttest2(boxplot_BAR_2(:,1), boxplot_BAR_4(:,1))
[h4,p4] = ttest2(boxplot_BAR_2(:,7), boxplot_BAR_4(:,7))
X1=[1,2];
% Original
X2=[1.3	2.3];
subplot(122)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('With Overlap p3 %d p4 %d',p3, p4))
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
hold off
set(gca,'xticklabel',{'Baseline 1','Baseline 2'})
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(3), g(1)], {'4 second', '2 second'});

%% BOXPLOT TUTTI IL TRAINING SUGLI OCCIPITALI

% O1 senza overlap
a=boxplot_BAR_1(:,1:7);
b=boxplot_BAR_3(:,1:7);
X1=[1,2,3,4,5,6,7];
X2=[1.3	2.3 3.3 4.3 5.3 6.3 7.3];
figure(), subplot(221)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('Channel O1 Without Overlap'), 'FontSize', 20), xlabel('Training Phase', 'FontSize', 18)
g = findall(gca,'Tag','Box');
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
g = findall(gca,'Tag','Box');
hold off
set(gca,'xticklabel',{'Baseline 1', 'Stress test','Relax: Minute 1', 'Relax: Minute 5', 'Relax: Minute 10', 'Relax: Minute 15','Baseline 2'}, 'XTickLabelRotation', 20, 'FontSize', 12)
groups = {[1, 1.3], [2, 2.3], [3, 3.3], [4, 4.4], [5, 5.3], [6, 6.3], [7, 7.3]};
sigstar(groups,p_val(1,:))
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(8), g(1)], {'4 second', '2 second'});

% O1 con overlap
a=boxplot_BAR_2(:,1:7);
b=boxplot_BAR_4(:,1:7);
[h3,p3] = ttest2(boxplot_BAR_2(:,1), boxplot_BAR_4(:,1))
[h4,p4] = ttest2(boxplot_BAR_2(:,7), boxplot_BAR_4(:,7))
subplot(222)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('Channel O1 with Overlap')), xlabel('Training Phase')
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
hold off
set(gca,'xticklabel',{'Baseline 1', 'Stress test','Relax: Minute 1', 'Relax: Minute 5', 'Relax: Minute 10', 'Relax: Minute 15','Baseline 2'}, 'XTickLabelRotation', 20, 'FontSize', 12)
groups = {[1, 1.3], [2, 2.3], [3, 3.3], [4, 4.4], [5, 5.3], [6, 6.3], [7, 7.3]};
sigstar(groups,p_val2(1,:))
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(8), g(1)], {'4 second', '2 second'});

% O2 senza overlap
a=boxplot_BAR_1(:,8:14);
b=boxplot_BAR_3(:,8:14);
subplot(223)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('Channel O2 Without Overlap')), xlabel('Training Phase')
g = findall(gca,'Tag','Box');
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
g = findall(gca,'Tag','Box');
hold off
set(gca,'xticklabel',{'Baseline 1', 'Stress test','Relax: Minute 1', 'Relax: Minute 5', 'Relax: Minute 10', 'Relax: Minute 15','Baseline 2'}, 'XTickLabelRotation', 20, 'FontSize', 12)
groups = {[1, 1.3], [2, 2.3], [3, 3.3], [4, 4.4], [5, 5.3], [6, 6.3], [7, 7.3]};
sigstar(groups,p_val(2,:))
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(8), g(1)], {'4 second', '2 second'});

% O2 con overlap
a=boxplot_BAR_2(:,8:14);
b=boxplot_BAR_4(:,8:14);
[h3,p3] = ttest2(boxplot_BAR_2(:,1), boxplot_BAR_4(:,1))
[h4,p4] = ttest2(boxplot_BAR_2(:,7), boxplot_BAR_4(:,7))
subplot(224)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('Channel O2 with Overlap')), xlabel('Training Phase')
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
hold off
set(gca,'xticklabel',{'Baseline 1', 'Stress test','Relax: Minute 1', 'Relax: Minute 5', 'Relax: Minute 10', 'Relax: Minute 15','Baseline 2'}, 'XTickLabelRotation', 20, 'FontSize', 12)
groups = {[1, 1.3], [2, 2.3], [3, 3.3], [4, 4.4], [5, 5.3], [6, 6.3], [7, 7.3]};
sigstar(groups,p_val(2,:))
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(8), g(1)], {'4 second', '2 second'});

sgtitle('Training over Occipital channel')

%% BOXPLOT TUTTI IL TRAINING SUI FRONTALI

% F3 Senza Overlap
a=boxplot_BAR_1(:,15:21);
b=boxplot_BAR_3(:,15:21);
X1=[1,2,3,4,5,6,7];
X2=[1.3	2.3 3.3 4.3 5.3 6.3 7.3];
figure(), subplot(221)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('Channel F3 Without Overlap')), xlabel('Training Phase')
g = findall(gca,'Tag','Box');
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
g = findall(gca,'Tag','Box');
hold off
set(gca,'xticklabel',{'Baseline 1', 'Stress test','Relax: Minute 1', 'Relax: Minute 5', 'Relax: Minute 10', 'Relax: Minute 15','Baseline 2'}, 'XTickLabelRotation', 20, 'FontSize', 12)
sigstar(groups,p_val(3,:))
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(8), g(1)], {'4 second', '2 second'});

% F3 Con overlap
a=boxplot_BAR_2(:,15:21);
b=boxplot_BAR_4(:,15:21);
[h3,p3] = ttest2(boxplot_BAR_2(:,1), boxplot_BAR_4(:,1))
[h4,p4] = ttest2(boxplot_BAR_2(:,7), boxplot_BAR_4(:,7))
subplot(222)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('Channel F3 with Overlap')), xlabel('Training Phase')
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
hold off
set(gca,'xticklabel',{'Baseline 1', 'Stress test','Relax: Minute 1', 'Relax: Minute 5', 'Relax: Minute 10', 'Relax: Minute 15','Baseline 2'}, 'XTickLabelRotation', 20, 'FontSize', 12)
sigstar(groups,p_val2(3,:))
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(8), g(1)], {'4 second', '2 second'});

% F4 senza overlap
a=boxplot_BAR_1(:,22:28);
b=boxplot_BAR_3(:,22:28);
subplot(223)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('Channel F4 Without Overlap')), xlabel('Training Phase')
g = findall(gca,'Tag','Box');
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
g = findall(gca,'Tag','Box');
hold off
set(gca,'xticklabel',{'Baseline 1', 'Stress test','Relax: Minute 1', 'Relax: Minute 5', 'Relax: Minute 10', 'Relax: Minute 15','Baseline 2'}, 'XTickLabelRotation', 20, 'FontSize', 12)
sigstar(groups,p_val(4,:))
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(8), g(1)], {'4 second', '2 second'});

% F4 con overlap
a=boxplot_BAR_2(:,22:28);
b=boxplot_BAR_4(:,22:28);
[h3,p3] = ttest2(boxplot_BAR_2(:,1), boxplot_BAR_4(:,1))
[h4,p4] = ttest2(boxplot_BAR_2(:,7), boxplot_BAR_4(:,7))
subplot(224)
boxplot(a,'positions',X1,'labels',X1,'colors','b','widths',0.25), ylim([0 1]), ylabel('BAR'), title(sprintf('Channel F4 with Overlap')), xlabel('Training Phase')
hold on
boxplot(b,'positions',X2,'labels',X2,'colors','r','widths',0.25)
hold off
set(gca,'xticklabel',{'Baseline 1', 'Stress test','Relax: Minute 1', 'Relax: Minute 5', 'Relax: Minute 10', 'Relax: Minute 15','Baseline 2'}, 'XTickLabelRotation', 20, 'FontSize', 12)
sigstar(groups,p_val2(4,:))
g = findall(gca,'Tag','Box');
hLegend2 = legend([g(8), g(1)], {'4 second', '2 second'});

sgtitle('Training over Frontal channel')

%% Calcolo dei p value di tutte le combinazioni
j = 4;
p_val = [];
p_val2 = [];
for ii = 1:4
    for j = 1:7
        [h,p] = ttest2(boxplot_BAR_1(:,j*ii), boxplot_BAR_3(:,j*ii));
        p_val(ii,j) = p;
        [h,p] = ttest2(boxplot_BAR_2(:,j*ii), boxplot_BAR_4(:,j*ii));
        p_val2(ii,j) = p;
    end
end
