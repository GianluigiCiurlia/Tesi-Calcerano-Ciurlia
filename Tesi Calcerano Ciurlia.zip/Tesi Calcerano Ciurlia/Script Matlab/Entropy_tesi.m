%Prova per calcolo del grado di entrainment (phase-locking) e per stabilire la frequenza di 
%stimolazione per lo stimolo visivo e uditivo

%Generiamo un'onda quadra che simuli la nostra stimolazione visiva. 
%Abbiamo un segnale EEG sinusoidale. 
%Calcoliamo la trasformata Hilbert e gli angoli di fase unwrapped di 
%entrambi i segnali, ne facciamo la sottrazione e ne calcoliamo istante per 
%istante l'Entropia normalizzata di Shannon. Più alto è il livello di 
%entropia maggiore sarà il grado di sincronizzazione e quindi di 
%entrainment. 

clear all 
close all 
clc 

%% Caricamento dati, definizione della parte utile del segnale
load 'Stimulation_Dile_15_febbraio.easy'
sign=Stimulation_Dile_15_febbraio;
%sign=Stimulation_G_31_01;

IAF=10.55;   %IAF calcolato prima della prova

%MARKER 1: INIZIO STIMOLAZIONE
%Durante la prova mettiamo un marker 1 dal NIC nel momento in cui parte la prima combinazione di luce
marker1= find(sign(:,12)==1);    %sulla colonna 12 vengono mostrati i marker inseriti durante l'acquisizione



%Quindi prendiamo su sign il segnale a partire dal campione a cui è stato fissato il marker 1 fino a
%contare 560000 campioni ((30 sec stim + 2 sec pausa) * 35 combinazioni * 500 samp/sec)
sign=sign(marker1:marker1+560000, 1);    %O1
% sign=sign(marker1:marker1+560000, 2);    %O2
% sign=sign(marker1:marker1+560000, 3);    %Pz
sign=sign';

%definisco il vettore delle intensità e il vettore delle frequenze
I=[0.3 0.54 0.97 1.75 3.15];
F=[IAF-3 IAF-2 IAF-1 IAF IAF+1 IAF+2 IAF+3];

fsamp=500;       %fsamp del segnale EEG
fNy = fsamp/2;


%IL SEGNALE EEG SARA' DI 1120 SECONDI (560000 campioni): divido il
%segnale 32s alla volta e lo metto in una matrice in cui su ogni riga ci
%sono 16000 campioni, ovvero 35 righe da 32 secondi ciascuno (35x16000),
%30s stim + 2s pausa
eeg=zeros(35,16000);
for i=1:35
xx=sign((i-1)*16000+1:(i*16000));
 if i==1
    eeg=[xx];
 else 
    eeg=[eeg;xx]; 
 end

end

%tolgo dalla matrice i primi 2 secondi di colonne e gli ultimi 4 secondi
%di colonne (2s iniziali e 2s finali vanno tolti per rendere l'analisi più
%attendibile, gli altri 2s finali sono la pausa)
eeg=eeg(:,1001:14000);



%% Creazione del segnale di stimolazione simulato : onda quadra
T = 32;   %durata di cui stiamo simulando avere il segnale onda quadra di stimolazione

x=0:1/fsamp:(T-1/fsamp);
stim=zeros(35,length(x));   %la matrice stim conterrà 35 combinazioni I-F di onda di stimolazione, ognuna su una riga

 k=1;
for i=1:5
    for j=1:7
     stim(k,:)=I(i)*square(2*pi*F(j).*x); %la matrice stim conterrà sulle righe prima le 7 onde ad ampiezza I1, poi le 7 onde ad ampiezza I2, ecc
     k=k+1;
    end
end

%anche a questa matrice di one quadre simulate devo togliere le colonne che
%corrispondono ai primi 2s e agli ultimi 4s
stim=stim(:,1001:14000);


%prova plot
 figure()
 subplot(2,1,1),plot(stim(4,:)), title('onde quadre a differente frequenza')
 subplot(2,1,2), plot(stim(32,:))
 
 

 %% Filtraggio
%Viene effettuato un filtraggio sull'onda quadra che la renderà con
%andamento più smussato. Lo stesso filtraggio viene fatto sul segnale eeg.
%La banda passante sarà tra IAF +- 3.5 Hz.

[b,a] = butter(6, [(IAF-3.5)  (IAF+3.5)]/fNy);
freqz(b,a, 500,500)

for i=1:35
stim_filt(i,:) = filtfilt(b, a, stim(i,:));
eeg_filt(i,:)=filtfilt(b,a,eeg(i,:));
end 

figure()
plot(stim(4,:),'r'), title('onda quadra e corrispondente onda filtrata, I1,f4')
hold on
plot(stim_filt(4,:),'b');
 
%% Calcolo del grado di Phase-Locking

%trasformate di Hilbert
Hilb_stim=zeros(35,length(stim_filt(1,:)));
Hilb_EEG=zeros(35,length(eeg_filt(1,:)));
Q_stim=zeros(35,length(stim_filt(1,:)));
Q_EEG=zeros(35,length(eeg_filt(1,:)));
shift=zeros(35,length(eeg_filt(1,:)));


for i=1:35
   
Hilb_stim(i,:) = hilbert(stim_filt(i,:)); 
Hilb_EEG(i,:) = hilbert(eeg_filt(i,:)); 
 
Q_stim(i,:) = (unwrap(angle(Hilb_stim(i,:))))'; 
Q_EEG(i,:) = (unwrap(angle(Hilb_EEG(i,:))))';
end

for i=1:35
 for j=1:length(eeg_filt(1,:))
     
shift(i,j) = Q_EEG(i,j)-Q_stim(i,j);     %calcolo dello shift tra gli angoli di EEG e gli angoli di stim alla rispettiva I e F
shift(i,j) = wrapToPi(shift(i,j));       % lo shift viene riportato tra -pi e +pi

 end
end

figure() 
plot(Q_stim(8,:), 'r'), title('Angoli unwrapped del segnale di stimolazione e del segnale EEG'); 
hold on
plot(Q_EEG(8,:), 'b');

figure(), plot(shift(8,:)), title('Shift di fase tra -pi e +pi')


%Calcolo della PSD per arrivare all'entropia di Shannon normalizzata

for j=1:35
[Pxx(j,:), f(j,:)] = pwelch((shift(j,:) - mean(shift(j,:))), rectwin(length(shift(j,:))), 0 , fsamp*T, fsamp);

pxx(j,:)=Pxx(j,:)./sum(Pxx(j,:)); 

for i=1:length(Pxx(j,:))
    if pxx(j,i)==0
        SE_vett(j,i)=0;   %poniamo a 0 l'entropia associata alle f che non portano contibuto 
    else
        SE_vett(j,i)=-pxx(j,i)*log(pxx(j,i));   %formula dell'entropia
    end
end
SE(j)=sum(SE_vett(j,:)); 
SE_max = log(length(pxx(j,:)));        %entropia massima
SE_n(j) = (SE_max-SE(j))/(SE_max);     %entropia normalizzata

end


%il vettore SE_n ha:
% da elemento 1 a elemento 7: le entropie di I1 con le 7 frequenze
% da elemento 8 a elemento 14: le entropie di I2 con le 7 frequenze
% da elemento 15 a elemento 21: le entropie di I3 con le 7 frequenze
% da elemento 22 a elemento 28: le entropie di I4 con le 7 frequenze
% da elemento 29 a elemento 35: le entropie di I5 con le 7 frequenze

%ridefinisco SE_n di modo che sia una matrice e che su ogni riga abbia i
%valori delle combinazioni di una singola I con tutte le F
SE_matrix=[SE(1:7); SE(8:14); SE(15:21); SE(22:28); SE(29:35)];

%SE_norm verrà plottata, ma per far sì che abbia le intensità crescenti dal
%basso verso l'alto sull'asse y, devo invertire la matrice
SE_norm=[SE_n(29:35); SE_n(22:28); SE_n(15:21); SE_n(8:14); SE_n(1:7)];

figure()
imagesc(SE_norm), title ("Arnold Tongue");
colormap(winter)       %questo comando plotta i valori delle intensità invertite, cioè dalla maggiore alla minore
colorbar
